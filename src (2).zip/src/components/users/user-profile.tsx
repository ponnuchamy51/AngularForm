import * as React from "react"
import { IProps, IState } from "../../interfaces/user"

class UserProfile extends React.Component<IProps, IState> {
    render() {
        return (
            <div className="row">
                <div className="col-12">
                    <h1>Profile Page</h1>
                </div>
            </div>
        )
    }
}

export default UserProfile;