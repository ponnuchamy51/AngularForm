import * as React from "react"
import { signIn } from "./../../actions"

import { connect } from 'react-redux'

interface IProps {
    signin?: any
}
class Product extends React.Component<IProps> {
    render() {
        return (
            <div className="row">
                <div className="col-12">
                    <h1>Products Page</h1>
                    <button
                        className="btn btn-danger ml-2"
                        onClick={() => { this.props.signin(); }}
                    >
                        signOuts
      </button>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state: any) => {
    return { isLogged: state.isLoggedIn };
};

const mapDispatchToProps = (dispatch: any) => {
    return {
        signin: () =>
            dispatch(signIn()),
    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Product);