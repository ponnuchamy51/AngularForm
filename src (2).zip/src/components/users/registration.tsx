import * as React from "react"

class Registration extends React.Component {
    render() {
        return (
            <div className="row">
                <div className="col-12">
                    <h1>Registration Page</h1>

                </div>
            </div>
        )
    }
}

export default Registration;