import * as React from "react"

class CartPage extends React.Component {
    render() {
        return (
            <div className="row">
                <div className="col-12">
                    <h1>Cart Page</h1>

                </div>
            </div>
        )
    }
}

export default CartPage;