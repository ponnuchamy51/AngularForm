import * as React from "react"
import { signIn } from "../../actions"
import { conditionalExpression } from "@babel/types"
import store from "../../stores"

import { connect } from 'react-redux'
import AppRouter from "../../AppRouter"
import DashboardRouter from "../../dashboardRouter"
import { TextField } from "../form_components/TextField"
interface IProps {
    isLogged: boolean
    signin?: any

}
interface IState {
    isLogged?: boolean
    username?: string
    password?: string

}

class LoginComponent extends React.Component<IProps, IState> {
    name: any
    constructor(props: any) {
        super(props)
        this.state = {};

    }
    UNSAFE_componentWillUpdate() {
        console.log(this.props)
    }
    changeHandler(event: any) {
        this.name = event.target.name;
        this.setState({
            [this.name]: event.target.value
        });
    }
    signin() {
        if (this.state.username == "pons" && this.state.password == "123456")
            this.props.signin()
        else
            alert("invalid username")
    }

    render() {
        return (
            <div className="row">
                <div className="col-12">
                    <br />
                    <h1>Log In</h1>
                    <br />

                    <form id="registrationForm">
                        {/* <input class="form-control" type="text" ref={this.myRef} /> */}
                        <div className="App col-12 justify-content-md-center">
                            <div className="form-group">
                                <label htmlFor="exampleInputEmail1">Username</label>
                                <TextField
                                    fieldName="username"
                                    fieldType="text"
                                    onTextChange={(e: any) => this.changeHandler(e)}
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="exampleInputEmail1">Password</label>
                                <TextField
                                    fieldType="text"
                                    fieldName="password"
                                    onTextChange={(e: any) => this.changeHandler(e)}
                                />
                            </div>
                        </div>
                    </form>
                    {(this.props.isLogged === false) ? <button
                        className="btn btn-danger ml-2"
                        onClick={() => { this.signin(); console.log(store.getState()) }}
                    >
                        signIn
      </button> : <button
                            className="btn btn-danger ml-2"
                            onClick={() => { this.signin(); console.log(store.getState()) }}
                        >
                            signOut
      </button>}


                </div>
            </div >
        )
    }
}


const mapStateToProps = (state: any) => {
    return { isLogged: state.isLoggedIn };
};

const mapDispatchToProps = (dispatch: any) => {
    return {
        signin: () =>
            dispatch(signIn()),

    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(LoginComponent);

