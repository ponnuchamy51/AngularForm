import React from "react";
interface IState {
    btnName: any
    btnAction: any
    btnClick: any
    resetForm: any
}

interface IProps {
    btnName: string
    btnAction: any
    btnClick: any
    resetForm: any
}

class SubmitBtn extends React.Component<IState, IProps> {
    constructor(probs: any) {
        super(probs);
    }
    render() {
        return (
            <div className="submit-block">
                <button
                    className="form-control"
                    type={this.props.btnName}
                    onClick={
                        this.props.btnAction === "submit"
                            ? this.props.btnClick
                            : this.props.resetForm
                    }
                    name="Submit"
                >
                    {this.props.btnName}
                </button>
            </div>
        );
    }
}

export { SubmitBtn };
