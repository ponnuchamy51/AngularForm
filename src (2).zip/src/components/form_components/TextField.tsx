import React from "react";

interface IProps {
    fieldType: string
    fieldName: string
    fieldValue: string
    fieldDisable: string
    onTextChange: any
    isRequired: boolean
    fieldMinLength: number
    fieldMaxLength: number
}
interface IState {
    fieldType: string
    fieldName: string
    fieldValue?: string
    fieldDisable?: boolean
    onTextChange?: any
    isRequired?: boolean
    fieldMinLength?: number
    fieldMaxLength?: number
}

class TextField extends React.Component<IState, IProps> {
    constructor(props: any) {
        super(props);
    }
    render() {
        return (
            <div className="textbox-block">
                <input
                    className="form-control"
                    type={this.props.fieldType}
                    name={this.props.fieldName}
                    value={this.props.fieldValue}
                    disabled={this.props.fieldDisable}
                    onChange={this.props.onTextChange}
                    required={this.props.isRequired}
                    maxLength={this.props.fieldMinLength}
                    minLength={this.props.fieldMaxLength}
                />
            </div>
        );
    }
}

export { TextField };
