import * as React from "react"
import { signIn } from "./actions"
import { conditionalExpression } from "@babel/types"
import store from "./stores"

import { connect } from 'react-redux'
import AppRouter from "./AppRouter"
import DashboardRouter from "./dashboardRouter"
interface IProps {
    isLogged: any

}
interface IState {
    isLogged?: any
    signin?: any

}

class LayoutComponent extends React.Component<IState, IProps> {
    constructor(props: any) {
        super(props)
        this.state = props
        console.log(this.state)
    }
    componentWillMount() {
        console.log(this.props, "321")
    }
    UNSAFE_componentWillUpdate() {
        console.log(this.props, "layout")
    }
    render() {
        return (
            <div className="row">
                <div className="col-12">
                    {(this.props.isLogged === false) ? <AppRouter /> : <DashboardRouter />}
                </div>
            </div >
        )
    }
}


const mapStateToProps = (state: any) => {
    return { isLogged: state.isLoggedIn };
};

const mapDispatchToProps = (dispatch: any) => {
    return {
        signin: () => dispatch(signIn()),

    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(LayoutComponent);

