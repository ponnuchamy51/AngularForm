import { createStore } from "redux";
import allReducer from "../reducers";

let store = createStore(
    allReducer
);
export default store;