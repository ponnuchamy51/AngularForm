import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Registration from './components/users/registration';
import LoginComponent from './components/common/login';
import UserProfile from './components/users/user-profile';
import CartPage from './components/users/cart';
import Product from './components/users/product';
import { signIn } from "./actions"



export class DashboardRouter extends React.Component {
    render() {
        return (
            <div className="Apps">
                <Router>
                    <Link to="/products" href="" className="text-white  btn btn-link">Products</Link>
                    <Link to="/cart" href="" className="text-white  btn btn-link">Cart</Link>
                    <Link to="/profile" className="text-white btn btn-link">Home</Link>

                    <Switch>
                        <Route path="/products" component={Product} />
                        <Route path="/cart" component={CartPage} />
                        <Route path="/profile" component={UserProfile} />
                    </Switch>
                </Router>
            </div>
        );
    }
}

export default DashboardRouter;
