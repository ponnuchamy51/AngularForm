import React from 'react';
import './App.css';
import { Provider } from "react-redux";
import store from "./stores";
import "bootstrap/dist/css/bootstrap.css"
import { signIn } from "./actions"

import AppRouter from './AppRouter';
import DashboardRouter from './dashboardRouter';
import LayoutComponent from './layout'
import { connect } from 'react-redux'
interface IProps {
  isLogged: boolean

}
interface IState {
  userName?: string
  signin?: any

}

class App extends React.Component<IState, IProps> {
  render() {
    let isLogged = this.props;
    console.log(isLogged, "123")
    return (
      <Provider store={store}>
        <div className="App container">
          <header className="App-header">
            <LayoutComponent />
          </header>
        </div>
      </Provider>
    );
  }
}



export default App;
