const signIn = () => ({
    type: "SIGN_IN"

});


export { signIn };