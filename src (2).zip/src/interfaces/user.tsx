import * as React from "react"

export interface IProfile {
    first_name: string
    last_name: string
    age: number
    phone: string
}

export interface IState {
    profile: IProfile
}

export interface IProps {
    profile: IProfile
}