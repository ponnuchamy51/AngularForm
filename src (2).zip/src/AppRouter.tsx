import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Registration from './components/users/registration';
import LoginComponent from './components/common/login';

interface IProps {
    isLogged: any
}
interface IState {
    test?: any
}

export class AppRouter extends React.Component<IState, IProps> {
    render() {
        return (
            <div className="Apps">
                <Router>
                    <Link to="/register" href="" className="text-white  btn btn-link">Register</Link>
                    <Link to="/login" className="text-white btn btn-link">Login</Link>
                    <Switch>
                        <Route path="/register" component={Registration} />
                        <Route path="/login" component={LoginComponent} />
                    </Switch>
                </Router>
            </div>
        );
    }
}

export default AppRouter;
